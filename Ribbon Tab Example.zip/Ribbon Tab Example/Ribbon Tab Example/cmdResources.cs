﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace RibbonTabExample
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdHelpDesk : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            // Open the webpage
            TaskDialog.Show("Webpage", "Open firm Help Desk page");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdStandards : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            // Open the webpage
            TaskDialog.Show("Webpage", "Open firm Standards page");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdBestPractices : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            // Open the webpage
            TaskDialog.Show("Webpage", "Open firm Best Practices page");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class cmdAutoBldg : IExternalCommand
    {
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData revit,
           ref string message, ElementSet elements)
        {
            TaskDialog.Show("Ha Ha", "Just Kidding!");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
    }    

    public class ResourcesShowButtonAlways : IExternalCommandAvailability
    {
        // Show the button as long as Revit is open
        public bool IsCommandAvailable(Autodesk.Revit.UI.UIApplication applicationData,
            CategorySet selectedCategories)
        {
            return true;
        }
    }
}