﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Windows;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace RibbonTabExample
{
    public class ApplicationClass : IExternalApplication
    {
        // Public variable
        static string _namespace_prefix = typeof(ApplicationClass).Namespace + ".";

        // Implement OnStartup method of IExternalApplication interface.
        public Result OnStartup(UIControlledApplication application)
        {
            // ExternalCommands assembly path
            Assembly oAssembly = Assembly.GetExecutingAssembly();
            string strAssemblyPath = Assembly.GetExecutingAssembly().Location;

            // Create ribbon tab
            string strRibbonTabName = "COBUG";
            application.CreateRibbonTab(strRibbonTabName);

            /*------------------------------------------------------------------------------------**/
            // New Ideas panel
            /*--------------+---------------+---------------+---------------+---------------+------*/
            // Add a new ribbon panel
            Autodesk.Revit.UI.RibbonPanel oNewIdeasRibbonPanel = application.CreateRibbonPanel(strRibbonTabName, "New Ideas");

            // Add a pushbutton
            PushButtonData oSuggestionsPushButtonData = new PushButtonData("Suggestions", "Suggestions", strAssemblyPath, "RibbonTabExample.cmdSuggestions");
            PushButton oSuggestionsPushButton = oNewIdeasRibbonPanel.AddItem(oSuggestionsPushButtonData) as PushButton;
            oSuggestionsPushButton.ToolTip = "If you have any suggestions or ideas for new tools we should create or acquire that will provide value to the firm, please send an email that explains in detail and you will be contacted to discuss";
            oSuggestionsPushButton.LargeImage = NewBitmapImage(oAssembly, "Suggestions.png");
            oSuggestionsPushButton.AvailabilityClassName = "RibbonTabExample.SuggestionsShowButtonAlways";

            /*------------------------------------------------------------------------------------**/
            // BIM 360 panel
            /*--------------+---------------+---------------+---------------+---------------+------*/
            // Add a new ribbon panel
            Autodesk.Revit.UI.RibbonPanel oBIM360PushButtonRibbonPanel = application.CreateRibbonPanel(strRibbonTabName, "BIM360");

            // Add a pushbutton with image
            PushButtonData oBIM360PushButtonData = new PushButtonData("Health", "Health", strAssemblyPath, "RibbonTabExample.cmdBIM360");
            PushButton oBIM360PushButton = oBIM360PushButtonRibbonPanel.AddItem(oBIM360PushButtonData) as PushButton;
            oBIM360PushButton.ToolTip = "This tool will open the Autodesk Health dashboard in Chrome or the default browser";
            oBIM360PushButton.LargeImage = NewBitmapImage(oAssembly, "Health.png");
            oBIM360PushButton.ToolTipImage = NewBitmapImage(oAssembly, "HealthSubscription.png");
            oBIM360PushButton.AvailabilityClassName = "RibbonTabExample.BIM360ShowButtonAlways";

            // Add a pushbutton
            PushButtonData oBIM360DocsPushButtonData = new PushButtonData("BIM360Docs", "BIM360Docs", strAssemblyPath, "RibbonTabExample.cmdBIM360Docs");
            PushButton oBIM360DocsPushButton = oBIM360PushButtonRibbonPanel.AddItem(oBIM360DocsPushButtonData) as PushButton;
            oBIM360DocsPushButton.ToolTip = "This tool will open the Autodesk BIM 360 Document Management portal in Chrome or the default browser";
            oBIM360DocsPushButton.LargeImage = NewBitmapImage(oAssembly, "BIM360.png");
            oBIM360DocsPushButton.AvailabilityClassName = "RibbonTabExample.BIM360ShowButtonAlways";
            /*--------------+---------------+---------------+---------------+---------------+------*/

            /*------------------------------------------------------------------------------------**/
            // Firm resources panel
            /*--------------+---------------+---------------+---------------+---------------+------*/
            // Add a new ribbon panel
            Autodesk.Revit.UI.RibbonPanel oResourcesRibbonPanel = application.CreateRibbonPanel(strRibbonTabName, "Resources");

            // Add a pushbutton
            PushButtonData oHelpDeskPushButtonData = new PushButtonData("HelpDesk", "HelpDesk", strAssemblyPath, "RibbonTabExample.cmdHelpDesk");
            PushButton oHelpDeskPushButton = oResourcesRibbonPanel.AddItem(oHelpDeskPushButtonData) as PushButton;
            oHelpDeskPushButton.ToolTip = "This tool will open your firm Help Desk webpage";
            oHelpDeskPushButton.LargeImage = NewBitmapImage(oAssembly, "HelpDesk.png");
            oHelpDeskPushButton.AvailabilityClassName = "RibbonTabExample.ResourcesShowButtonAlways";

            // Add a pushbutton
            PushButtonData oStandardsButtonData = new PushButtonData("Standards", "Standards", strAssemblyPath, "RibbonTabExample.cmdStandards");
            PushButton oStandardsPushButton = oResourcesRibbonPanel.AddItem(oStandardsButtonData) as PushButton;
            oStandardsPushButton.ToolTip = "This tool will open your firm Standards webpage";
            oStandardsPushButton.LargeImage = NewBitmapImage(oAssembly, "Standards.png");
            oStandardsPushButton.AvailabilityClassName = "RibbonTabExample.ResourcesShowButtonAlways";

            // Add a pushbutton
            PushButtonData oBestPracticesButtonData = new PushButtonData("BestPractices", "BestPractices", strAssemblyPath, "RibbonTabExample.cmdBestPractices");
            PushButton oBestPracticesPushButton = oResourcesRibbonPanel.AddItem(oBestPracticesButtonData) as PushButton;
            oBestPracticesPushButton.ToolTip = "This tool will open your firm Revit Best Practices webpage";
            oBestPracticesPushButton.LargeImage = NewBitmapImage(oAssembly, "BestPractices.png");
            oBestPracticesPushButton.AvailabilityClassName = "RibbonTabExample.ResourcesShowButtonAlways";
            /*--------------+---------------+---------------+---------------+---------------+------*/

            /*------------------------------------------------------------------------------------**/
            // Firm Tools panel
            /*--------------+---------------+---------------+---------------+---------------+------*/
            // Add a new ribbon panel
            Autodesk.Revit.UI.RibbonPanel oToolsRibbonPanel = application.CreateRibbonPanel(strRibbonTabName, "Tools");

            // Add a pushbutton with video
            PushButtonData oAutoBldgPushButtonData = new PushButtonData("AutoBldg", "AutoBldg", strAssemblyPath, "RibbonTabExample.cmdAutoBldg");
            PushButton oAutoBldgPushButton = oToolsRibbonPanel.AddItem(oAutoBldgPushButtonData) as PushButton;
            oAutoBldgPushButton.LargeImage = NewBitmapImage(oAssembly, "Magic_32.png");
            
            // Needed for video
            RibbonToolTip oRibbonToolTipVideo = new RibbonToolTip();
            oRibbonToolTipVideo.Title = "Automatically design building";
            oRibbonToolTipVideo.ExpandedVideo = new Uri(Path.GetDirectoryName(strAssemblyPath) + @"\AutoBldg.mp4");
            oRibbonToolTipVideo.ExpandedContent = "No need for designers, this button will design and create the building for you!";
            SetRibbonItemToolTipVideo(oAutoBldgPushButton, oRibbonToolTipVideo);

            return Autodesk.Revit.UI.Result.Succeeded;
        }

        // Implement OnShutdown method of IExternalApplication interface.
        public Result OnShutdown(UIControlledApplication application)
        {
            // nothing to clean up in this simple case
            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the BitmapImage images
        /// </summary>
        /// <returns> BitmapImage </returns>
        /// <author>Dan.Tartaglia </author>                              <date>03/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        BitmapImage NewBitmapImage(Assembly oAssembly, string strImageName)
        {
            try
            {
                Stream oStream = oAssembly.GetManifestResourceStream(_namespace_prefix + strImageName);

                BitmapImage oBitmapImage = new BitmapImage();

                oBitmapImage.BeginInit();
                oBitmapImage.StreamSource = oStream;
                oBitmapImage.EndInit();

                return oBitmapImage;
            }
            catch (Exception ex)
            {
                Autodesk.Revit.UI.TaskDialog.Show("Error", ex.Message);                
                return null;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Logic needed to setup and run the video
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>08/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        void SetRibbonItemToolTipVideo(Autodesk.Revit.UI.RibbonItem item, RibbonToolTip toolTip)
        {
            IUIRevitItemConverter itemConverter = new InternalMethodUIRevitItemConverter();

            var ribbonItem = itemConverter.GetRibbonItem(item);
            if (ribbonItem == null)
                return;
            ribbonItem.ToolTip = toolTip;
        }
    }
}

