﻿namespace BestPractices01
{
    partial class WorksetSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WorksetSelect));
            this.lbxWorksets = new System.Windows.Forms.ListBox();
            this.btnActivate = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbxWorksets
            // 
            this.lbxWorksets.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbxWorksets.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxWorksets.FormattingEnabled = true;
            this.lbxWorksets.ItemHeight = 20;
            this.lbxWorksets.Location = new System.Drawing.Point(12, 52);
            this.lbxWorksets.Name = "lbxWorksets";
            this.lbxWorksets.Size = new System.Drawing.Size(362, 344);
            this.lbxWorksets.TabIndex = 2;
            this.lbxWorksets.DoubleClick += new System.EventHandler(this.lbxWorksets_DoubleClick);
            // 
            // btnActivate
            // 
            this.btnActivate.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnActivate.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnActivate.Location = new System.Drawing.Point(155, 423);
            this.btnActivate.Name = "btnActivate";
            this.btnActivate.Size = new System.Drawing.Size(75, 23);
            this.btnActivate.TabIndex = 0;
            this.btnActivate.Text = "Activate";
            this.btnActivate.UseVisualStyleBackColor = true;
            this.btnActivate.Click += new System.EventHandler(this.btnActivate_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(12, 18);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(294, 17);
            this.lblMessage.TabIndex = 3;
            this.lblMessage.Text = "The current active Workset is selected below:";
            // 
            // WorksetSelect
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(386, 468);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnActivate);
            this.Controls.Add(this.lbxWorksets);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WorksetSelect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select the needed active Workset";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxWorksets;
        private System.Windows.Forms.Button btnActivate;
        private System.Windows.Forms.Label lblMessage;
    }
}