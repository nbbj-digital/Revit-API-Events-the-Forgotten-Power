﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace BestPractices01
{
    public partial class WorksetSelect : System.Windows.Forms.Form
    {
        private Workset oActiveWorkset = null;
        private UIApplication oUIApp = null;

        public WorksetSelect(UIApplication oUIApplication)
        {
            oUIApp = oUIApplication;

            InitializeComponent();

            try
            {
                // Get the workset table from the document
                WorksetTable worksetTable = oUIApp.ActiveUIDocument.Document.GetWorksetTable();

                // Get the Id of the active workset
                WorksetId activeId = worksetTable.GetActiveWorksetId();

                // Get the active workset with the Id 
                oActiveWorkset = worksetTable.GetWorkset(activeId);

                PopulateListBox(oUIApp);

                // Create the ToolTip and associate with the Form container.
                System.Windows.Forms.ToolTip toolTip1 = new System.Windows.Forms.ToolTip();

                // Set up the delays for the ToolTip.
                toolTip1.AutoPopDelay = 5000;
                toolTip1.InitialDelay = 500;
                toolTip1.ReshowDelay = 500;

                // Set up the ToolTip text
                toolTip1.SetToolTip(lbxWorksets, "Double-click  a Workset or select a Workset and click: Activate");
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Populate the listbox
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void PopulateListBox(UIApplication oUIApp)
        {
            try
            {
                List<string> lstAllWorksets = new List<string>();
                List<string> lstWorksets = new List<string>();                

                // Clear all items
                lbxWorksets.Items.Clear();

                // Enumerating worksets in a document and getting basic information for each
                FilteredWorksetCollector collector = new FilteredWorksetCollector(oUIApp.ActiveUIDocument.Document);

                // find all user worksets
                collector.OfKind(WorksetKind.UserWorkset);
                IList<Workset> worksets = collector.ToWorksets();

                // Get each user created workset
                foreach (Workset workset in worksets)
                {
                    lstAllWorksets.Add(workset.Name);
                }

                // Sort the items
                lstAllWorksets.Sort();

                // Get all Worksets besides the active
                foreach(string strAllWorkset in lstAllWorksets)
                {
                    if (!strAllWorkset.Equals(oActiveWorkset.Name, StringComparison.Ordinal))
                        lstWorksets.Add(strAllWorkset);                        
                }

                // Add the active Workset first
                lbxWorksets.Items.Add(oActiveWorkset.Name);

                // Add all other Worksets
                foreach (string strWorkset in lstWorksets)
                {
                    lbxWorksets.Items.Add(strWorkset);
                }

                // Select the first/active Workset
                lbxWorksets.SetSelected(0, true);
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
                return;
            }
        }

        private void btnActivate_Click(object sender, EventArgs e)
        {
            try
            {
                string selectedItem = string.Empty;

                try
                {
                    // Get the selected Workset item
                    selectedItem = lbxWorksets.Items[lbxWorksets.SelectedIndex].ToString();
                }
                catch
                {
                    TaskDialog.Show("Nothing selected", "Please select a Workset");
                    return;
                }

                // Enumerating worksets in a document and getting basic information for each
                FilteredWorksetCollector collector = new FilteredWorksetCollector(oUIApp.ActiveUIDocument.Document);

                // find all user worksets
                collector.OfKind(WorksetKind.UserWorkset);
                IList<Workset> worksets = collector.ToWorksets();

                // Get each workset
                foreach (Workset workset in worksets)
                {
                    if (workset.Name.Equals(selectedItem, StringComparison.Ordinal))
                    {
                        try
                        {
                            // Use a Transaction to modify the model
                            Transaction oTransaction = new Transaction(oUIApp.ActiveUIDocument.Document);
                            oTransaction.Start("Activate the Workset");

                            // Get the workset table from the document
                            WorksetTable worksetTable = oUIApp.ActiveUIDocument.Document.GetWorksetTable();

                            // Set the wanted Workset as active
                            worksetTable.SetActiveWorksetId(workset.Id);

                            oTransaction.Commit();
                            this.Close();
                            break;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error", ex.Message);
                return;
            }
        }

        private void lbxWorksets_DoubleClick(object sender, EventArgs e)
        {
            btnActivate_Click(null, null);
        }
    }
}
