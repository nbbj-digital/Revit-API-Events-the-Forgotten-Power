﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Timers;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;

namespace DataMining
{    
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]

    public class ApplicationClass : IExternalApplication
    {
        // Public variables
        public static bool blnModelDataProcess = true;
        public static string strLogFilePathName = string.Empty;
        public static List<string> strLogValuesToWrite = new List<string>();
        public static List<string> strAddinNames = new List<string>();
        public static Stopwatch oRevitStopWatch = null;        
        public static Stopwatch oStopWatch = null;

        public static Array oMetricsArray;
        public static int intValuesCntr = 0;
        public static int intDocumentCntr = 0;
        public static int intDynamoOpeningsCntr = 0;
        public static int intMetricsArrayCntr = 33;

        public static string strMetricsDLLVersion = string.Empty;

        public static System.Timers.Timer oHeartBeatTimer = null;
        public static int intHeartBeatInterval = 900000;

        public static Autodesk.Revit.DB.Document m_RevitDocument;
        public static Autodesk.Revit.UI.UIControlledApplication m_RevitApplication;

        public static DefaultValues oDefaultValues = new DefaultValues();

        public Autodesk.Revit.UI.Result OnStartup(UIControlledApplication application)
        {
            // Get the DLL File Version value
            strMetricsDLLVersion = Utilities.GetFileVersion();

            // Get the application object
            m_RevitApplication = application;

            // Register the events
            application.ControlledApplication.DocumentOpening += new EventHandler<DocumentOpeningEventArgs>(DocumentOpeningEvent);
            application.ControlledApplication.DocumentOpened += new EventHandler<DocumentOpenedEventArgs>(DocumentOpenedEvent);
            application.ControlledApplication.DocumentSaving += new EventHandler<DocumentSavingEventArgs>(DocumentSavingEvent);
            application.ControlledApplication.DocumentSaved += new EventHandler<DocumentSavedEventArgs>(DocumentSavedEvent);
            application.ControlledApplication.DocumentSavingAs += new EventHandler<DocumentSavingAsEventArgs>(DocumentSavingAsEvent);
            application.ControlledApplication.DocumentSavedAs += new EventHandler<DocumentSavedAsEventArgs>(DocumentSavedAsEvent);
            application.ControlledApplication.DocumentSynchronizingWithCentral += new EventHandler<DocumentSynchronizingWithCentralEventArgs>(DocumentSynchronizingWithCentralEvent);
            application.ControlledApplication.DocumentSynchronizedWithCentral += new EventHandler<DocumentSynchronizedWithCentralEventArgs>(DocumentSynchronizedWithCentralEvent);
            application.ControlledApplication.DocumentClosing += new EventHandler<DocumentClosingEventArgs>(DocumentClosingEvent);
            Autodesk.Windows.ComponentManager.ItemExecuted += OnItemExecutedEvent;

            // Start the heartbeat timer            
            SetHeartBeatTimer(intHeartBeatInterval);

            // Start the stopwatch to get the event duration
            oRevitStopWatch = new Stopwatch();
            oRevitStopWatch.Start();

            // Create a new array
            oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
            
            // Set the flag
            blnModelDataProcess = false;

            // Extract the metrics
            MetricsExtract("RevitOnStartup", null, blnModelDataProcess, TimeSpan.Zero, null);

            // Write to the CSV
            CSVWrite(oMetricsArray);

            // Create a new array
            intValuesCntr = 0;
            oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);

            // Add-Ins to monitor for
            strAddinNames.Add("Dynamo");

            return Autodesk.Revit.UI.Result.Succeeded;
        }
        
        // Implement OnShutdown method of IExternalApplication interface. 
        public Autodesk.Revit.UI.Result OnShutdown(UIControlledApplication application)
        {
            // Un-Register the events
            application.ControlledApplication.DocumentOpening -= new EventHandler<DocumentOpeningEventArgs>(DocumentOpeningEvent);
            application.ControlledApplication.DocumentOpened -= new EventHandler<DocumentOpenedEventArgs>(DocumentOpenedEvent);
            application.ControlledApplication.DocumentSaving -= new EventHandler<DocumentSavingEventArgs>(DocumentSavingEvent);
            application.ControlledApplication.DocumentSaved -= new EventHandler<DocumentSavedEventArgs>(DocumentSavedEvent);
            application.ControlledApplication.DocumentSavingAs -= new EventHandler<DocumentSavingAsEventArgs>(DocumentSavingAsEvent);
            application.ControlledApplication.DocumentSavedAs -= new EventHandler<DocumentSavedAsEventArgs>(DocumentSavedAsEvent);
            application.ControlledApplication.DocumentSynchronizingWithCentral -= new EventHandler<DocumentSynchronizingWithCentralEventArgs>(DocumentSynchronizingWithCentralEvent);
            application.ControlledApplication.DocumentSynchronizedWithCentral -= new EventHandler<DocumentSynchronizedWithCentralEventArgs>(DocumentSynchronizedWithCentralEvent);
            application.ControlledApplication.DocumentClosing -= new EventHandler<DocumentClosingEventArgs>(DocumentClosingEvent);
            Autodesk.Windows.ComponentManager.ItemExecuted -= OnItemExecutedEvent;

            // Stop the StopWatch
            oRevitStopWatch.Stop();

            // Get the elapsed time as a TimeSpan value
            TimeSpan oTimeSpan = oRevitStopWatch.Elapsed;

            // Set the flag
            blnModelDataProcess = false;

            // Extract the metrics
            MetricsExtract("RevitOnShutdown", null, blnModelDataProcess, oTimeSpan, null);

            // Write to the CSV
            CSVWrite(oMetricsArray);
            intValuesCntr = 0;
            return Autodesk.Revit.UI.Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentOpening event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentOpeningEvent(Object sender, DocumentOpeningEventArgs args)
        {
            // Only extract metrics from RVT files
            if (Path.GetExtension(args.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
            {
                // Start the stopwatch to get the event duration
                oStopWatch = new Stopwatch();
                oStopWatch.Start();                
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentOpened event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentOpenedEvent(Object sender, DocumentOpenedEventArgs args)
        {
            try
            {
                // Only extract metrics from RVT files         
                if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase) ||
                    args.Document.PathName == string.Empty)
                {
                    // Stop the StopWatch
                    oStopWatch.Stop();

                    // Get the elapsed time as a TimeSpan value
                    TimeSpan oTimeSpan = oStopWatch.Elapsed;

                    // Set the flag
                    blnModelDataProcess = true;

                    // Get the ModelPath of the document if worksharing is enabled
                    ModelPath oModelPath = WSModelPathGet(args.Document);                   

                    // Extract the metrics
                    MetricsExtract("DocumentOpened", oModelPath, blnModelDataProcess, oTimeSpan, args.Document);

                    // Write to the CSV
                    CSVWrite(oMetricsArray);

                    // Create a new array
                    intValuesCntr = 0;
                    oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSaving event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSavingEvent(Object sender, DocumentSavingEventArgs args)
        {
            // Only extract metrics from RVT files
            if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase) ||
                args.Document.PathName == string.Empty)
            {
                // Start the stopwatch to get the event duration
                oStopWatch = new Stopwatch();
                oStopWatch.Start();
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSaved event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSavedEvent(Object sender, DocumentSavedEventArgs args)
        {
            try
            {
                // Only extract metrics from RVT files
                if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
                {
                    // Stop the StopWatch
                    oStopWatch.Stop();

                    // Get the elapsed time as a TimeSpan value
                    TimeSpan oTimeSpan = oStopWatch.Elapsed;

                    // Set the flag
                    blnModelDataProcess = true;

                    // Get the ModelPath of the document if worksharing is enabled
                    ModelPath oModelPath = WSModelPathGet(args.Document);

                    // Extract the metrics
                    MetricsExtract("DocumentSaved", oModelPath, blnModelDataProcess, oTimeSpan, args.Document);

                    // Write to the CSV
                    CSVWrite(oMetricsArray);

                    // Create a new array
                    intValuesCntr = 0;
                    oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSavingAs event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSavingAsEvent(Object sender, DocumentSavingAsEventArgs args)
        {
            // Only extract metrics from RVT files
            if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase) ||
                args.Document.PathName == string.Empty)
            {
                // Start the stopwatch to get the event duration
                oStopWatch = new Stopwatch();
                oStopWatch.Start();
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSavedAs event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSavedAsEvent(Object sender, DocumentSavedAsEventArgs args)
        {
            try
            {
                // Only extract metrics from RVT files
                if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
                {
                    // Stop the StopWatch
                    oStopWatch.Stop();

                    // Get the elapsed time as a TimeSpan value
                    TimeSpan oTimeSpan = oStopWatch.Elapsed;

                    // Set the flag
                    blnModelDataProcess = true;

                    // Get the ModelPath of the document if worksharing is enabled
                    ModelPath oModelPath = WSModelPathGet(args.Document);

                    // Extract the metrics
                    MetricsExtract("DocumentSavedAs", oModelPath, blnModelDataProcess, oTimeSpan, args.Document);

                    // Write to the CSV
                    CSVWrite(oMetricsArray);

                    // Create a new array
                    intValuesCntr = 0;
                    oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSynchronizingWithCentral event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSynchronizingWithCentralEvent(Object sender, DocumentSynchronizingWithCentralEventArgs args)
        {
            // Start the stopwatch to get the event duration
            oStopWatch = new Stopwatch();
            oStopWatch.Start();
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentSynchronizedWithCentral event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentSynchronizedWithCentralEvent(Object sender, DocumentSynchronizedWithCentralEventArgs args)
        {
            try
            {
                // Stop the StopWatch
                oStopWatch.Stop();

                // Get the elapsed time as a TimeSpan value
                TimeSpan oTimeSpan = oStopWatch.Elapsed;

                // Set the flag
                blnModelDataProcess = true;

                // Get the ModelPath of the document if worksharing is enabled
                ModelPath oModelPath = WSModelPathGet(args.Document);

                // Extract the metrics
                MetricsExtract("DocumentSynchronized", oModelPath, blnModelDataProcess, oTimeSpan, args.Document);

                // Write to the CSV
                CSVWrite(oMetricsArray);

                // Create a new array
                intValuesCntr = 0;
                oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentClosing event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentClosingEvent(Object sender, DocumentClosingEventArgs args)
        {
            string strElapsedOpenTime = string.Empty;

            try
            {
                // Only extract metrics from RVT files                
                if (Path.GetExtension(args.Document.PathName).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
                {
                    // Attempt to get the active view. This will prevent writing metrics in the 
                    // scenario when a user opens a document and the Worksets dialog appears
                    Autodesk.Revit.DB.View oView = args.Document.ActiveView;

                    // Set the flag
                    blnModelDataProcess = true;

                    // Get the ModelPath of the document if worksharing is enabled
                    ModelPath oModelPath = WSModelPathGet(args.Document);

                    // Extract the metrics
                    MetricsExtract("DocumentClosing", oModelPath, blnModelDataProcess, TimeSpan.Zero, args.Document);

                    // Write to the CSV
                    CSVWrite(oMetricsArray);

                    // Create a new array
                    intValuesCntr = 0;
                    oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// OnItemExecuted event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void OnItemExecutedEvent(object sender, Autodesk.Internal.Windows.RibbonItemExecutedEventArgs e)
        {
            try
            {
                foreach(string strAddinName in strAddinNames)
                {
                    if (e.Item.AutomationName.StartsWith(strAddinName, StringComparison.CurrentCultureIgnoreCase))
                        intDynamoOpeningsCntr++;
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Set or reset the timer
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>12/2016</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void SetHeartBeatTimer(int intTimer)
        {
            // Create a timer with a interval
            oHeartBeatTimer = new System.Timers.Timer(intTimer);

            // Hook up the Elapsed event for the timer
            oHeartBeatTimer.Elapsed += OnHeartBeatTimedEvent;
        }

        // Captures event when the timer reaches it's defined elapsed time
        /*------------------------------------------------------------------------------------**/
        /// <author>Dan.Tartaglia </author>                              <date>12/2016</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private static void OnHeartBeatTimedEvent(Object source, ElapsedEventArgs e)
        {
            // Set the flag
            blnModelDataProcess = false;

            try
            {
                // Extract the metrics
                MetricsExtract("HeartBeat", null, blnModelDataProcess, TimeSpan.Zero, null);

                // Write to the CSV
                CSVWrite(oMetricsArray);

                // Create a new array
                intValuesCntr = 0;
                oMetricsArray = Array.CreateInstance(typeof(object), 1, intMetricsArrayCntr);
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the ModelPath object for workshared models
        /// </summary>
        /// <returns> ModelPath </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static ModelPath WSModelPathGet(Document oDoc)
        {
            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)

                    // Get the ModelPath object
                    return oDoc.GetWorksharingCentralModelPath();
            }
            catch
            {
                return null;
            }
            return null;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Resize array
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private static Array ResizeArray(Array arr, int[] newSizes)
        {
            if (newSizes.Length != arr.Rank)
                throw new ArgumentException("arr must have the same number of dimensions " +
                                            "as there are elements in newSizes", "newSizes");

            var temp = Array.CreateInstance(arr.GetType().GetElementType(), newSizes);
            int length = arr.Length <= temp.Length ? arr.Length : temp.Length;
            Array.ConstrainedCopy(arr, 0, temp, 0, length);
            return temp;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Saved metrics to an external file
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static void MetricsExtract(string strRevitEvent, ModelPath oModelPath, bool blnModelDataProcess,
            TimeSpan oElapsedTime, Document oDoc)
        {
            bool blnValue = false;
            int intValue = 0;
            long lngValue = 0;
            ulong ulgValue = 0;
            double dblValue = 0;
            string strValue = string.Empty;
            string strFilePath = string.Empty;
            string strFileName = string.Empty;

            try
            {
                oDefaultValues = new DefaultValues();

                // Resize array
                oMetricsArray = (object[,])ResizeArray(oMetricsArray, new int[] { intValuesCntr + 1, intMetricsArrayCntr });

                // Add CollectionDate
                oMetricsArray.SetValue(DateTime.Now, intValuesCntr, 0);

                // Add CollectionTime
                oMetricsArray.SetValue(DateTime.Now, intValuesCntr, 1);

                // Add RevitEvent
                oMetricsArray.SetValue(strRevitEvent, intValuesCntr, 2);

                // Add RevitEventDuration
                strValue = oElapsedTime.TotalSeconds.ToString();

                if (strValue == string.Empty)
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 3);
                else
                    oMetricsArray.SetValue(strValue, intValuesCntr, 3);

                // Add UserName
                strValue = Utilities.EnvironmentVariableGet("USERNAME");
                if (strValue == null)
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 4);
                else if (!strValue.Equals(string.Empty))
                    oMetricsArray.SetValue(strValue, intValuesCntr, 4);
                else
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 4);

                // Add ComputerAvailableHDgigs
                dblValue = Utilities.HDDataGet(@"c:\", DefaultValues.HardDriveValues.Free);
                if (dblValue != -1)
                    oMetricsArray.SetValue(dblValue, intValuesCntr, 5);
                else
                    oMetricsArray.SetValue(0, intValuesCntr, 5);

                // Get ComputerAvailableRAMmbs
                ulgValue = Utilities.GetAvailMemoryInBytes();

                if (ulgValue != 0)
                    oMetricsArray.SetValue(Convert.ToInt64((ulgValue) / (1024 * 1024)), intValuesCntr, 6);
                else
                    oMetricsArray.SetValue(0, intValuesCntr, 6);

                // Get ComputerWirelessEnabled
                blnValue = Utilities.IsWirelessEnabled();
                if (blnValue == true)
                    oMetricsArray.SetValue("True", intValuesCntr, 7);
                else
                    oMetricsArray.SetValue("False", intValuesCntr, 7);

                try
                {
                    // Add ComputerTempFileCount
                    if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                    {
                        IEnumerable<string> enumFiles = Utilities.DirectoryFileNumberGet(Environment.GetEnvironmentVariable("TEMP"), "*");
                        string[] arrFiles = enumFiles.ToArray();
                        oMetricsArray.SetValue(arrFiles.Length, intValuesCntr, 8);
                    }
                }
                catch
                {
                    oMetricsArray.SetValue(-1, intValuesCntr, 8);
                }

                // Add RevitDynamoOpenings
                if (strRevitEvent.Equals("DocumentClosing", StringComparison.CurrentCultureIgnoreCase))
                    oMetricsArray.SetValue(intDynamoOpeningsCntr, intValuesCntr, 9);

                try
                {
                    // Add RevitC4RBuildNumber
                    if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (File.Exists(DefaultValues.strRevitC4RBuildNumber))
                        {
                            var varFileVersionInfo = FileVersionInfo.GetVersionInfo(DefaultValues.strRevitC4RBuildNumber);
                            oMetricsArray.SetValue(varFileVersionInfo.ProductVersion, intValuesCntr, 10);
                        }
                        else
                            oMetricsArray.SetValue(string.Empty, intValuesCntr, 10);
                    }
                }
                catch
                {
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 10);
                }

                try
                {
                    // Add RevitAcceleratorBuildNumber
                    if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (File.Exists(DefaultValues.strRevitAcceleratorBuildNumber))
                        {
                            var varFileVersionInfo = FileVersionInfo.GetVersionInfo(DefaultValues.strRevitAcceleratorBuildNumber);
                            oMetricsArray.SetValue(varFileVersionInfo.ProductVersion, intValuesCntr, 11);
                        }
                        else
                            oMetricsArray.SetValue(string.Empty, intValuesCntr, 11);
                    }
                }
                catch
                {
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 11);
                }

                try
                {
                    // Add RevitDesktopConnectorBuildNumber
                    if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (File.Exists(DefaultValues.strRevitDesktopConnectorBuildNumber))
                        {
                            var varFileVersionInfo = FileVersionInfo.GetVersionInfo(DefaultValues.strRevitDesktopConnectorBuildNumber);
                            oMetricsArray.SetValue(varFileVersionInfo.ProductVersion, intValuesCntr, 12);
                        }
                        else
                            oMetricsArray.SetValue(string.Empty, intValuesCntr, 12);
                    }
                }
                catch
                {
                    oMetricsArray.SetValue(string.Empty, intValuesCntr, 12);
                }

                // Get RevitVersionName
                if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                {
                    strValue = m_RevitApplication.ControlledApplication.VersionName;
                    if (strValue == null)
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 13);
                    else if (!strValue.Equals(string.Empty))
                        oMetricsArray.SetValue(strValue, intValuesCntr, 13);
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 13);
                }

                // Get RevitBuildNumber
                if (strRevitEvent.Equals("RevitOnShutdown", StringComparison.CurrentCultureIgnoreCase))
                {
                    strValue = m_RevitApplication.ControlledApplication.VersionBuild;

                    if (strValue == null)
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 14);
                    else if (!strValue.Equals(string.Empty))
                        oMetricsArray.SetValue(strValue, intValuesCntr, 14);
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 14);
                }

                if (blnModelDataProcess == true)
                {
                    // Add RevitFileWorksharingEnabled
                    if (oDoc.IsWorkshared)
                    {
                        // Determine if the file is in BIM 360
                        if (RevitFilePathValueGet(oModelPath, DefaultValues.RevitFilePathValues.Path, oDoc).StartsWith("BIM 360:"))
                            oMetricsArray.SetValue(null, intValuesCntr, 15);
                        else
                            oMetricsArray.SetValue("True", intValuesCntr, 15);
                    }
                    else
                        oMetricsArray.SetValue("False", intValuesCntr, 15);

                    // Add RevitFileIsCentralFile
                    if (oDoc.IsWorkshared)
                    {
                        // Determine if the file is in BIM 360
                        if (RevitFilePathValueGet(oModelPath, DefaultValues.RevitFilePathValues.Path, oDoc).StartsWith("BIM 360:"))
                            oMetricsArray.SetValue(null, intValuesCntr, 16);
                        else
                        {
                            strValue = RevitDetermineIfCentral(oModelPath, oDoc);
                            if (strValue == null)
                                oMetricsArray.SetValue(string.Empty, intValuesCntr, 16);
                            else if (!strValue.Equals(string.Empty))
                                oMetricsArray.SetValue(strValue, intValuesCntr, 16);
                            else
                                oMetricsArray.SetValue(string.Empty, intValuesCntr, 16);
                        }
                    }
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 16);

                    // Add RevitFileIsDetached
                    strValue = RevitDetermineIfDetached(oModelPath, oDoc);
                    if (strValue == "True")
                        oMetricsArray.SetValue("True", intValuesCntr, 17);
                    else if (strValue == "False")
                        oMetricsArray.SetValue("False", intValuesCntr, 17);
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 17);

                    // Add RevitFilePath
                    strFilePath = RevitFilePathValueGet(oModelPath, DefaultValues.RevitFilePathValues.Path, oDoc);
                    if (strFilePath == null)
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 18);
                    else if (!strFilePath.Equals(string.Empty))
                        oMetricsArray.SetValue(strFilePath, intValuesCntr, 18);
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 18);

                    // Add RevitFileName
                    strFileName = RevitFilePathValueGet(oModelPath, DefaultValues.RevitFilePathValues.Name, oDoc);
                    if (strFileName == null)
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 19);
                    else if (!strFileName.Equals(string.Empty))
                        oMetricsArray.SetValue(strFileName, intValuesCntr, 19);
                    else
                        oMetricsArray.SetValue(string.Empty, intValuesCntr, 19);

                    // Add RevitFileDateCreated
                    oMetricsArray.SetValue(RevitFileDateTimeGet(oModelPath, DefaultValues.RevitFilePathValues.DateCreated, oDoc), intValuesCntr, 20);

                    // Add RevitFileDateModified
                    oMetricsArray.SetValue(RevitFileDateTimeGet(oModelPath, DefaultValues.RevitFilePathValues.DateModified, oDoc), intValuesCntr, 21);

                    // Add RevitFileSizeKbs
                    intValue = RevitFileSizeGet(oModelPath, DefaultValues.RevitFilePathValues.FileSize, oDoc);
                    if (intValue != -1)
                        oMetricsArray.SetValue(intValue, intValuesCntr, 22);
                    else
                        oMetricsArray.SetValue(0, intValuesCntr, 22);

                    // Add RevitFileNumOfRVTLinks
                    lngValue = RevitRVTLinksGet(oDoc);
                    if (lngValue == 0)
                        oMetricsArray.SetValue(0, intValuesCntr, 23);
                    else if (lngValue == -1)
                        oMetricsArray.SetValue(0, intValuesCntr, 23);
                    else
                        oMetricsArray.SetValue(Convert.ToInt32(lngValue), intValuesCntr, 23);

                    // Add RevitFileNumOfCADLinks
                    // Formats: DWG, DXF, DGN, SAT, SKP, 3dm
                    lngValue = RevitCADLinksGet(DefaultValues.RevitCadObjects.Links, oDoc);
                    if (lngValue == 0)
                        oMetricsArray.SetValue(0, intValuesCntr, 24);
                    else if (lngValue == -1)
                        oMetricsArray.SetValue(0, intValuesCntr, 24);
                    else
                        oMetricsArray.SetValue(Convert.ToInt32(lngValue), intValuesCntr, 24);

                    // Add RevitFileNumOfCADImports
                    // Formats: DWG, DXF, DGN, SAT, SKP, 3dm
                    lngValue = RevitCADLinksGet(DefaultValues.RevitCadObjects.Imports, oDoc);

                    if (lngValue == 0)
                        oMetricsArray.SetValue(0, intValuesCntr, 25);
                    else if (lngValue == -1)
                        oMetricsArray.SetValue(0, intValuesCntr, 25);
                    else
                        oMetricsArray.SetValue(Convert.ToInt32(lngValue), intValuesCntr, 25);

                    // Add RevitFileNumOfDesignOptionSets
                    lngValue = DesignOptionSetsGet(oDoc);
                    if (lngValue == 0)
                        oMetricsArray.SetValue(0, intValuesCntr, 26);
                    else if (lngValue == -1)
                        oMetricsArray.SetValue(0, intValuesCntr, 26);
                    else
                        oMetricsArray.SetValue(Convert.ToInt32(lngValue), intValuesCntr, 26);

                    // Add RevitFileNumOfDesignOptions
                    intValue = BuiltInCategoryGet(BuiltInCategory.OST_DesignOptions, oDoc);
                    if (intValue != -1)
                        oMetricsArray.SetValue(intValue, intValuesCntr, 27);
                    else
                        oMetricsArray.SetValue(0, intValuesCntr, 27);

                    // Add RevitFileNumOfViews
                    intValue = ViewsGet(oDoc);
                    if (intValue != -1)
                        oMetricsArray.SetValue(intValue, intValuesCntr, 28);
                    else
                        oMetricsArray.SetValue(0, intValuesCntr, 28);

                    // Add RevitFileNumOfReferencePlanes
                    oMetricsArray.SetValue(ReferencePlanesGet(oDoc), intValuesCntr, 29);

                    // Add RevitFileNumOfFilledRegionInstances
                    intValue = FilledRegionsGet(oDoc);
                    if (intValue != -1)
                        oMetricsArray.SetValue(intValue, intValuesCntr, 30);
                    else
                        oMetricsArray.SetValue(0, intValuesCntr, 30);

                    // Add RevitFileNumOfWarnings
                    lngValue = RevitWarningsGet(oDoc);
                    if (lngValue == 0)
                        oMetricsArray.SetValue(0, intValuesCntr, 31);
                    else if (lngValue == -1)
                        oMetricsArray.SetValue(0, intValuesCntr, 31);
                    else
                        oMetricsArray.SetValue(Convert.ToInt32(lngValue), intValuesCntr, 31);

                    // Add Last
                    if (strRevitEvent.Equals("DocumentClosing", StringComparison.CurrentCultureIgnoreCase))
                        oMetricsArray.SetValue(1, intValuesCntr, 32);
                    else
                        oMetricsArray.SetValue(0, intValuesCntr, 32);
                }

                intValuesCntr++;                
            }
            catch(Exception e)
            {
                if (!File.Exists(DefaultValues.strErrorLog))
                    // Write to the error file
                    Utilities.TextFileWrite(DefaultValues.strErrorLog, e.Message, true);
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number of Design Option Sets
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long DesignOptionSetsGet(Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfCategory(BuiltInCategory.OST_DesignOptionSets);
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the CAD link values
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long RevitCADLinksGet(DefaultValues.RevitCadObjects oRevitCadObjects, Document oDoc)
        {
            int result = 0;
            long lngValue = 0;
            string strExtension = string.Empty;
            string strRefPath = string.Empty;

            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                FilteredElementIterator itor = 
                    oFiltElemCollector.OfClass(typeof(Autodesk.Revit.DB.ImportInstance)).GetElementIterator();
                itor.Reset();

                // Iterate through each object found
                while (itor.MoveNext())
                {
                    // Get the object
                    ImportInstance imp = itor.Current as ImportInstance;

                    // Process linked objects
                    if (imp.IsLinked)
                    {
                        // Get the object
                        ExternalFileReference el = ExternalFileUtils.GetExternalFileReference(oDoc, imp.GetTypeId());

                        // Verify the element is not null
                        if (el != null)
                        {
                            if (oRevitCadObjects == DefaultValues.RevitCadObjects.Links)
                            {
                                // Get the string of the path of a given ModelPath
                                strRefPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(el.GetAbsolutePath());

                                if (Path.GetExtension(strRefPath).Equals(".DWG", StringComparison.CurrentCultureIgnoreCase) ||                                    
                                    Path.GetExtension(strRefPath).Equals(".DXF", StringComparison.CurrentCultureIgnoreCase) ||
                                    Path.GetExtension(strRefPath).Equals(".DGN", StringComparison.CurrentCultureIgnoreCase) ||
                                    Path.GetExtension(strRefPath).Equals(".SAT", StringComparison.CurrentCultureIgnoreCase) ||
                                    Path.GetExtension(strRefPath).Equals(".SKP", StringComparison.CurrentCultureIgnoreCase))
                                    lngValue++;
                            }
                        }
                    }
                    else
                    {
                        if (imp.Category == null)
                            continue;

                        if (oRevitCadObjects == DefaultValues.RevitCadObjects.Imports)
                        {
                            // Determines if one string is within the other
                            result = Utilities.IsStringFound(".dwg", imp.Category.Name);

                            if (result >= 0)
                                lngValue++;

                            // Determines if one string is within the other
                            result = Utilities.IsStringFound(".dxf", imp.Category.Name);

                            if (result >= 0)
                                lngValue++;

                            // Determines if one string is within the other
                            result = Utilities.IsStringFound(".dgn", imp.Category.Name);

                            if (result >= 0)
                                lngValue++;

                            // Determines if one string is within the other
                            result = Utilities.IsStringFound(".sat", imp.Category.Name);

                            if (result >= 0)
                                lngValue++;

                            // Determines if one string is within the other
                            result = Utilities.IsStringFound(".skp", imp.Category.Name);

                            if (result >= 0)
                                lngValue++;
                        }
                    }
                }
            }
            catch
            {
                return -1;
            }
            return lngValue;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number of all RVT links
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long RevitRVTLinksGet(Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfClass(typeof(RevitLinkInstance));
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number of warnings
        /// </summary>
        /// <returns> long </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2018</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static long RevitWarningsGet(Document oDoc)
        {
            try
            {
                IList<FailureMessage> lstMessages = oDoc.GetWarnings();
                return lstMessages.Count;
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a RVT is a central file or local file
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitDetermineIfCentral(ModelPath oModelPath, Document oDoc)
        {
            string strFullPath = string.Empty;

            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return string.Empty;

                    if (strFullPath.Equals(string.Empty))
                        return string.Empty;

                    // Remove the 1st 3 chars from the opening file path
                    string strPartialOpenPath = oDoc.PathName.Substring(3, oDoc.PathName.Length - 3);

                    // Determine if the opening file path exists in the central file path
                    int intResult = Utilities.IsStringFound(strPartialOpenPath, strFullPath);

                    if (intResult >= 0 || oDoc.PathName.Equals(strFullPath))
                        return "True";
                    else
                        return "False";
                }
                else
                    return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Determine if a RVT is detached (should be easier in newer versions)
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitDetermineIfDetached(ModelPath oModelPath, Document oDoc)
        {
            string strFullPath = string.Empty;

            try
            {
                if (oDoc == null)
                    return string.Empty;

                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return "True";

                    if (strFullPath.Equals(string.Empty))
                        return "True";

                    if (Path.GetExtension(strFullPath).Equals(".rvt", StringComparison.CurrentCultureIgnoreCase))
                        return "False";
                }
                else
                    // non-workshared file
                    return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get date and time values
        /// </summary>
        /// <returns> DateTime </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static DateTime RevitFileDateTimeGet(ModelPath oModelPath, 
            DefaultValues.RevitFilePathValues oRevitFilePathValues, Document oDoc)
        {
            string strFullPath = string.Empty;            

            try
            {
                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return DateTime.MinValue;

                    if (strFullPath.Equals(string.Empty))
                        return DateTime.MinValue;

                    // Get the date created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate;
                    }

                    // Get the time created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate;
                    }

                    // Get the date modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate;
                    }

                    // Get the time modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate;
                    }
                }
                else
                {
                    // Handle non-workshared files                    
                    strFullPath = oDoc.PathName;

                    if (strFullPath == null)
                        return DateTime.MinValue;

                    if (strFullPath.Equals(string.Empty))
                        return DateTime.MinValue;

                    // Get the date created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate;

                    }

                    // Get the time created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate;
                    }

                    // Get the date modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate;
                    }

                    // Get the time modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate;
                    }
                }
            }
            catch
            {
                return DateTime.MinValue;
            }
            return DateTime.MinValue;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get file size values
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int RevitFileSizeGet(ModelPath oModelPath, 
            DefaultValues.RevitFilePathValues oRevitFilePathValues, Document oDoc)
        {
            long lngValue = 0;
            string strFullPath = string.Empty;

            try
            {
                // Look for C4R files
                if (oDoc.PathName.StartsWith(DefaultValues.strC4RAppendedValue01) ||
                    oDoc.PathName.StartsWith(DefaultValues.strC4RAppendedValue02))
                {
                    DefaultValues oDefaultValues = new DefaultValues();

                    // Extract all basicfileinfo...dat file names
                    oDefaultValues.lstBasicfileinfoFullPaths = Utilities.BasicfileinfoFilesGet("basicfileinfo.",
                        DefaultValues.strCollaborationCachePath);

                    if (oDefaultValues.lstBasicfileinfoFullPaths.Count == 0)
                        return -1;

                    // Get the full path for the wanted C4R file
                    strFullPath = Utilities.RVTFullPathGet(oDefaultValues.lstBasicfileinfoFullPaths, oDoc.PathName);

                    if (strFullPath == null)
                        return -1;

                    if (strFullPath.Equals(string.Empty))
                        return -1;

                    lngValue = Utilities.FileSizeGet(strFullPath);
                    if (lngValue == 0)
                        return -1;
                    else
                        return Convert.ToInt32(lngValue);
                }

                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return -1;

                    if (strFullPath.Equals(string.Empty))
                        return -1;

                    // Get the file size
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.FileSize)
                    {
                        lngValue = Utilities.FileSizeGet(strFullPath);
                        if (lngValue == 0)
                            return -1;
                        else
                            return Convert.ToInt32(lngValue);
                    }
                }
                else
                {
                    // Handle non-workshared files                    
                    strFullPath = oDoc.PathName;

                    if (strFullPath == null)
                        return -1;

                    if (strFullPath.Equals(string.Empty))
                        return -1;                    

                    // Get the file size
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.FileSize)
                    {
                        lngValue = Utilities.FileSizeGet(strFullPath);
                        if (lngValue == 0)
                            return -1;
                        else
                            return Convert.ToInt32(lngValue);
                    }
                }
            }
            catch
            {
                return -1;
            }
            return -1;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get central file path, dates and size values
        /// </summary>
        /// <returns> string </returns>
        /// <author>Dan.Tartaglia </author>                              <date>04/2015</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static string RevitFilePathValueGet(ModelPath oModelPath, 
            DefaultValues.RevitFilePathValues oRevitFilePathValues, Document oDoc)
        {
            long lngValue = 0;
            string strFullPath = string.Empty;

            try
            {
                // Get the name of the current country
                string strCountryCode = Utilities.CountryCodeGet();

                // Determine if worksharing enabled
                if (oDoc.IsWorkshared)
                {
                    if (oModelPath == null)
                        // Get the central file full path
                        oModelPath = oDoc.GetWorksharingCentralModelPath();

                    // Get the string of the path of a given ModelPath
                    strFullPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(oModelPath);

                    if (strFullPath == null)
                        return string.Empty;

                    if (strFullPath.Equals(string.Empty))
                        return string.Empty;

                    // Get the file path
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.Path)
                        return Path.GetDirectoryName(strFullPath);

                    // Get the file name
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.Name)
                        return Path.GetFileName(strFullPath);

                    // Get the date created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate.ToString("yyyyMMdd", 
                            System.Globalization.CultureInfo.GetCultureInfo(strCountryCode));
                    }

                    // Get the time created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate.ToString("HH:mm:ss");
                    }

                    // Get the date modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate.ToString("yyyyMMdd", 
                            System.Globalization.CultureInfo.GetCultureInfo(strCountryCode));
                     }

                    // Get the time modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate.ToString("HH:mm:ss");
                    }

                    // Get the file size
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.FileSize)
                    {
                        lngValue = Utilities.FileSizeGet(strFullPath);
                        if (lngValue == 0)
                            return string.Empty;
                        else
                            return lngValue.ToString();
                    }
                }
                else
                {
                    // Handle non-workshared files                    
                    strFullPath = oDoc.PathName;

                    if (strFullPath == null)
                        return string.Empty;

                    if (strFullPath.Equals(string.Empty))
                        return string.Empty;

                    // Get the file path
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.Path)
                        return Path.GetDirectoryName(strFullPath);

                    // Get the file name
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.Name)
                        return Path.GetFileName(strFullPath);

                    // Get the date created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate.ToString("yyyyMMdd", 
                            System.Globalization.CultureInfo.GetCultureInfo(strCountryCode));

                    }

                    // Get the time created
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeCreated)
                    {
                        DateTime fileCreatedDate = File.GetCreationTime(strFullPath);
                        return fileCreatedDate.ToString("HH:mm:ss");
                    }

                    // Get the date modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.DateModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate.ToString("yyyyMMdd", 
                            System.Globalization.CultureInfo.GetCultureInfo(strCountryCode));
                    }

                    // Get the time modified
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.TimeModified)
                    {
                        DateTime fileModifiedDate = File.GetLastWriteTime(strFullPath);
                        return fileModifiedDate.ToString("HH:mm:ss");
                    }

                    // Get the file size
                    if (oRevitFilePathValues == DefaultValues.RevitFilePathValues.FileSize)
                    {
                        lngValue = Utilities.FileSizeGet(strFullPath);
                        if (lngValue == 0)
                            return string.Empty;
                        else
                            return lngValue.ToString();
                    }
                }
            }
            catch
            {
                return string.Empty;
            }
            return string.Empty;
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number as per BuiltInCategory
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>11/2016</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int BuiltInCategoryGet(BuiltInCategory oBuiltInCategory, Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfCategory(oBuiltInCategory);
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number of filled region instances
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>05/2018</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int FilledRegionsGet(Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfClass(typeof(Autodesk.Revit.DB.FilledRegion));
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number views (schedules and sheets not included)
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>11/2016</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int ViewsGet(Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfCategory(BuiltInCategory.OST_Views);
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the number reference planes
        /// </summary>
        /// <returns> int </returns>
        /// <author>Dan.Tartaglia </author>                              <date>11/2016</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static int ReferencePlanesGet(Document oDoc)
        {
            try
            {
                // Create a collector to get the wanted elements
                FilteredElementCollector oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector = new FilteredElementCollector(oDoc);
                oFiltElemCollector.OfClass(typeof(Autodesk.Revit.DB.ReferencePlane));
                return oFiltElemCollector.Count();
            }
            catch
            {
                return -1;
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Write the record info to the csv file
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private static void CSVWrite(Array oMetricsArray)
        {
            try
            {
                string strValue = string.Empty;
                string strValueMerge = string.Empty;

                // Add the headers if the CSV does not exist
                if (!File.Exists(DefaultValues.strCSVLogFilePath))
                {
                    string strTitles = "CollectionDate,CollectionTime,RevitEvent,RevitEventDuration,UserName,ComputerAvailableHDgigs,ComputerAvailableRAMmbs,ComputerWirelessEnabled,ComputerTempFileCount,RevitDynamoOpenings,RevitC4RBuildNumber,RevitAcceleratorBuildNumber,RevitDesktopConnectorBuildNumber,RevitVersionName,RevitBuildNumber,RevitFileWorksharingEnabled,RevitFileIsCentralFile,RevitFileIsDetached,RevitFilePath,RevitFileName,RevitFileDateCreated,RevitFileDateModified,RevitFileSizeKbs,RevitFileNumOfRVTLinks,RevitFileNumOfCADLinks,RevitFileNumOfCADImports,RevitFileNumOfDesignOptionSets,RevitFileNumOfDesignOptions,RevitFileNumOfViews,RevitFileNumOfReferencePlanes,RevitFileNumOfFilledRegionInstances,RevitFileNumOfWarnings,Last";
                    Utilities.TextFileWrite(DefaultValues.strCSVLogFilePath, strTitles, false);                    
                }

                ResetLastValue(DefaultValues.strCSVLogFilePath, oMetricsArray);

                // Iterate the array (each record)
                foreach(var varValue in oMetricsArray)
                {
                    try
                    {
                        strValue = varValue.ToString();
                    }
                    catch
                    {
                        strValue = string.Empty;
                    }

                    // Combine the values into one comma delimiter string
                    strValueMerge += strValue + ",";                       
                }

                // Write to the CSV
                Utilities.TextFileWrite(DefaultValues.strCSVLogFilePath, strValueMerge, true);

                try
                {
                    // Reset the timer
                    oHeartBeatTimer.Enabled = false;
                    oHeartBeatTimer.AutoReset = false;
                    oHeartBeatTimer.Enabled = true;
                }
                catch
                {
                }
            }
            catch
            {
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Set the last opened model as the latest (Last field = 1 for each unique model)
        /// </summary>
        /// <returns> void </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private static void ResetLastValue(string strCSVLogFilePath, Array oMetricsArray)
        {
            try
            {
                bool blnFirstLine = true;
                string strLine = string.Empty;
                string strCurrentFullPath = string.Empty;
                List<string> lstValueMerged = new List<string>();                

                try
                {
                    // Attempt to get the path and file name
                    strCurrentFullPath = oMetricsArray.GetValue(0, 18).ToString() + "," + oMetricsArray.GetValue(0, 19).ToString();
                }
                catch
                {
                    return;
                }                

                if (strCurrentFullPath.Equals(string.Empty))
                    return;

                // Read the file
                StreamReader strFile = new StreamReader(strCSVLogFilePath);

                // Iterate throught the CSV file
                while ((strLine = strFile.ReadLine()) != null)
                {
                    // Determine if the current path and name writing to the CSV has the same name as a previous
                    if (strLine.Contains(strCurrentFullPath))
                    {
                        // Determine if the line ends with 1
                        if (strLine.EndsWith(",1,") || strLine.EndsWith(",1"))
                        {
                            // Replace it with 0
                            strLine = strLine.Remove(strLine.Length - 2) + "0,";

                            // Add to the list
                            lstValueMerged.Add(strLine);
                            continue;
                        }
                    }

                    if (blnFirstLine == true)
                    {
                        blnFirstLine = false;

                        // Add headers to the list
                        lstValueMerged.Add(strLine);
                    }
                    else
                        // Add to the list
                        lstValueMerged.Add(strLine);
                }
                // Close the CSV
                strFile.Close();

                try
                {
                    // Delete the current CSV
                    if (File.Exists(DefaultValues.strCSVLogFilePath))
                        File.Delete(DefaultValues.strCSVLogFilePath);
                }
                catch
                {
                    return;
                }

                if (lstValueMerged.Count > 0)
                {
                    // Iterate through each text line and create the CSV
                    foreach (string sttValueMerged in lstValueMerged)
                    {
                        // Write to the CSV
                        Utilities.TextFileWrite(DefaultValues.strCSVLogFilePath, sttValueMerged, true);
                    }
                }
            }
            catch
            {
            }
        }
    }
}