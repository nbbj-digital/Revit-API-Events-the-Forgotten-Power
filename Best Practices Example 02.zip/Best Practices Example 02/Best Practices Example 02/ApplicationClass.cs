﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;

namespace BestPractices02
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class ApplicationClass : IExternalApplication
    {
        // Implement OnStartup method of IExternalApplication interface.
        public Result OnStartup(UIControlledApplication application)
        {
            // Register the events
            application.ControlledApplication.FamilyLoadingIntoDocument += new EventHandler<FamilyLoadingIntoDocumentEventArgs>(FamilyLoadingIntoDocumentEvent);
            application.ControlledApplication.DocumentChanged += new EventHandler<DocumentChangedEventArgs>(DocumentChangedEvent);

            /*------------------------------------------------------------------------------------**/
            // Register the IUpdater Interface
            /*--------------+---------------+---------------+---------------+---------------+------*/
            // Register the CeilingAndFloor Updater
            CeilingAndFloorUpdater oCeilingAndFloorUpdater = new CeilingAndFloorUpdater(application.ActiveAddInId);
            UpdaterRegistry.RegisterUpdater(oCeilingAndFloorUpdater, true);
            
            // Specify the class and filter
            ElementClassFilter oCeilingAndFloorFilter = new ElementClassFilter(typeof(CeilingAndFloor));

            // Add/define the trigger
            UpdaterRegistry.AddTrigger(oCeilingAndFloorUpdater.GetUpdaterId(), oCeilingAndFloorFilter,
                                        Element.GetChangeTypeElementDeletion());

            return Result.Succeeded;
        }

        // Implement OnShutdown method of IExternalApplication interface.
        public Result OnShutdown(UIControlledApplication application)
        {
            // Un-Register the events
            application.ControlledApplication.FamilyLoadingIntoDocument -= new EventHandler<FamilyLoadingIntoDocumentEventArgs>(FamilyLoadingIntoDocumentEvent);
            application.ControlledApplication.DocumentChanged -= new EventHandler<DocumentChangedEventArgs>(DocumentChangedEvent);

            /*------------------------------------------------------------------------------------**/
            // Un-Register the IUpdater Interface
            /*--------------+---------------+---------------+---------------+---------------+------*/
            CeilingAndFloorUpdater oCeilingAndFloorUpdater = new CeilingAndFloorUpdater(application.ActiveAddInId);
            UpdaterRegistry.UnregisterUpdater(oCeilingAndFloorUpdater.GetUpdaterId());

            return Result.Succeeded;
        }

        /*------------------------------------------------------------------------------------**/
        /// FamilyLoadingIntoDocument event method
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void FamilyLoadingIntoDocumentEvent(object sender, FamilyLoadingIntoDocumentEventArgs e)
        {
            // Get the full path for the RFA
            string strFamilyFullPath = e.FamilyPath + e.FamilyName + ".rfa";

            // Make sure the family can be found
            if (File.Exists(strFamilyFullPath))
            {
                // Get the file size of the family
                double dblFileSize = FileSizeGet(strFamilyFullPath);

                // Show a message if the family is > 3 MBs
                if (dblFileSize > 3)
                {
                    // Creates a Revit task dialog to communicate information to the user
                    TaskDialog mainDialog = new TaskDialog("Alert");
                    mainDialog.MainInstruction = "Alert: Loading Large Family '" + e.FamilyName + "'";
                    mainDialog.MainContent =
                        "You are currently loading a family with the size: " + dblFileSize.ToString() + " MBs."
                        + " Are you sure you want to load the family?";

                    mainDialog.CommonButtons = TaskDialogCommonButtons.No | TaskDialogCommonButtons.Yes;
                    mainDialog.DefaultButton = TaskDialogResult.No;
                    TaskDialogResult tResult = mainDialog.Show();

                    if (tResult == TaskDialogResult.No)
                    {
                        try
                        {
                            // Cancel the family from loading
                            if (e.Cancellable)
                                e.Cancel();
                        }
                        catch
                        {                                                       
                        }
                    }
                }
            }
        }

        /*------------------------------------------------------------------------------------**/
        /// DocumentChangedEvent event method
        /// <author>Dan.Tartaglia </author>                              <date>07/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        private void DocumentChangedEvent(object sender, DocumentChangedEventArgs e)
        {
            ICollection<ElementId> oElementIdsAdded = e.GetAddedElementIds();
            ICollection<ElementId> oElementIdsDeleted = e.GetDeletedElementIds();
            ICollection<ElementId> oElementIdsModified = e.GetModifiedElementIds();

            if (oElementIdsAdded.Count > 0)
                TaskDialog.Show("Added", "Elements added: " + oElementIdsAdded.Count.ToString());

            if (oElementIdsDeleted.Count > 0)
                TaskDialog.Show("Deleted", "Elements deleted: " + oElementIdsDeleted.Count.ToString());

            if (oElementIdsModified.Count > 0)
                TaskDialog.Show("Modified", "Elements modified: " + oElementIdsModified.Count.ToString());
        }

        /*------------------------------------------------------------------------------------**/
        /// <summary>
        /// Get the file size in MBs
        /// </summary>
        /// <returns> double </returns>
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public static double FileSizeGet(string strFilePathName)
        {
            try
            {
                FileInfo fInfo = new FileInfo(strFilePathName);
                double dblSize = Convert.ToDouble(fInfo.Length);

                return (dblSize / 1024) / 1000;
            }
            catch
            {
                return 0;
            }
        }
    }
}

