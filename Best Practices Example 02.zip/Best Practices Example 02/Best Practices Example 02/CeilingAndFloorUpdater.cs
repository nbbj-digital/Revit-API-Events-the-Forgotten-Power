﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace BestPractices02
{
    public class CeilingAndFloorUpdater : IUpdater
    {
        static AddInId m_appId;
        static UpdaterId m_updaterId;

        /*------------------------------------------------------------------------------------**/
        /// Get the updater id
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public CeilingAndFloorUpdater(AddInId id)
        {
            m_appId = id;
            m_updaterId = new UpdaterId(m_appId, new Guid("C9182E45-BBED-44E4-A1ED-0B0D4C48C74E"));
        }

        /*------------------------------------------------------------------------------------**/
        /// Execute the specified action
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public void Execute(UpdaterData data)
        {
            // Get the active document
            Document oDocument = data.GetDocument();

            // Get all elements deleted that meet the criteria
            ICollection<ElementId> colElementIds = data.GetDeletedElementIds();

            // Creates a Revit task dialog to communicate information to the user
            TaskDialog mainDialog = new TaskDialog("Alert");
            mainDialog.MainInstruction = "Alert: Ceiling and/or Floor Deletion";
            mainDialog.MainContent =
                "You are deleting " + colElementIds.Count.ToString() + " Ceilings and/or Floors."
                + " Doing so can unintentionally delete many other objects from the model as well."
                + " If this was done by accident, please perform an Undo.";

            mainDialog.CommonButtons = TaskDialogCommonButtons.Close;
            mainDialog.DefaultButton = TaskDialogResult.Close;
            TaskDialogResult tResult = mainDialog.Show();
        }

        /*------------------------------------------------------------------------------------**/
        /// Auxiliary text that Revit will use to inform the end user when the Updater is not 
        /// loaded
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public string GetAdditionalInformation()
        {
            return "Warns when a user deletes a ceiling or floor";
        }

        /*------------------------------------------------------------------------------------**/
        /// Specifies the priority of an Updater during execution
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public ChangePriority GetChangePriority()
        {
            return ChangePriority.FloorsRoofsStructuralWalls;
        }

        /*------------------------------------------------------------------------------------**/
        /// Returns globally unique updater id - used to identify the Updater Called once during 
        /// registration of the updater
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public UpdaterId GetUpdaterId()
        {
            return m_updaterId;
        }

        /*------------------------------------------------------------------------------------**/
        /// Returns a name that the Updater can be identified by to the user
        /// <author>Dan.Tartaglia </author>                              <date>06/2019</date>
        /*--------------+---------------+---------------+---------------+---------------+------*/
        public string GetUpdaterName()
        {
            return "Ceiling and floor Updater";
        }
    }
}
